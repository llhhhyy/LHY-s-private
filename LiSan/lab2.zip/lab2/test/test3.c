int test3(int a) {
    assert(a >= 0);
}
