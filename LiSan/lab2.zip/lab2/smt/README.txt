1、在lab2目录中启动命令行输入"./install_z3.sh"安装Z3。

2、Z3的示例程序在smt.cpp中，在本目录下打开命令行输入make就可以编译执行smt.cpp。

3、在z3文件夹下面的examples/c++/example.cpp里有更多C++示例程序。
   示例教程请看http://www.cs.utah.edu/~vinu/research/formal/tools/notes/z3-notes.html