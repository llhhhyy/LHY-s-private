#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <zlib.h>
#include <assert.h>
#include <stdlib.h>
#include <minisat/core/Solver.h>
